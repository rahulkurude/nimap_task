
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('api_app', '0012_remove_client_mobile_number_client_contact_and_more'),
    ]

    operations = [
        migrations.AlterField(
            model_name='client',
            name='contact',
            field=models.CharField(max_length=15),
        ),
        migrations.AlterField(
            model_name='user',
            name='phone_number',
            field=models.CharField(max_length=15, null=True),
        ),
    ]
