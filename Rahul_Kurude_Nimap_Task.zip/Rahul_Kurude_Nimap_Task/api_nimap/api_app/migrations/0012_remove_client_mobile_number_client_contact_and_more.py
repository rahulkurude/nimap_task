

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('api_app', '0011_alter_user_options_remove_user_location_and_more'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='client',
            name='mobile_number',
        ),
        migrations.AddField(
            model_name='client',
            name='contact',
            field=models.BigIntegerField(default=1),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='user',
            name='Location_City',
            field=models.CharField(max_length=255, null=True),
        ),
        migrations.AlterField(
            model_name='user',
            name='address',
            field=models.CharField(max_length=255, null=True),
        ),
        migrations.AlterField(
            model_name='user',
            name='phone_number',
            field=models.BigIntegerField(null=True),
        ),
    ]
