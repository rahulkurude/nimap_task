

from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('api_app', '0014_alter_client_contact'),
    ]

    operations = [
        migrations.RenameField(
            model_name='project',
            old_name='name',
            new_name='Project_name',
        ),
    ]
