

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('api_app', '0013_alter_client_contact_alter_user_phone_number'),
    ]

    operations = [
        migrations.AlterField(
            model_name='client',
            name='contact',
            field=models.BigIntegerField(),
        ),
    ]
